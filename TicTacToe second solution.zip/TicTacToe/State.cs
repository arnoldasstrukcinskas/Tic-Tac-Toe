﻿namespace TicTacToe
{
    public enum State { Undecided, X, O };
}
